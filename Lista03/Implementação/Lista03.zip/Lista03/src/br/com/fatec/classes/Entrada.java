/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.classes;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author T-Gamer
 */
public class Entrada {
    
    private final List<String> tipolist = new ArrayList<>();
    private final List<String> nomelist = new ArrayList<>();
    private final List<String> valorlist = new ArrayList<>();
    private final List<String> datalist = new ArrayList<>();

    public String getTipolist(int n){
        return tipolist.get(n);
    }

    public String getNomelist(int n){
        return nomelist.get(n);
    }

    public String getValorlist(int n){
        return valorlist.get(n);
    }
    
    public String getDatalist(int n){
        return datalist.get(n);
    }
    
    public String setTipolist(int n ,String valor){
        return tipolist.set(n, valor);
    }
    
    public String setNomelist(int n ,String valor){
        return nomelist.set(n, valor);
    }
    
    public String setValorlist(int n ,String valor){
        return valorlist.set(n, valor);
    }
    
     public String setDatalist(int n ,String valor){
        return datalist.set(n, valor);
    }
    
    public int getIndex(){
        return valorlist.size();
    }
    
    public void addTipolist(String valor){
        tipolist.add(valor);
    }
    
    public void addNomelist(String valor){
        nomelist.add(valor);
    }
    
    public void addValorlist(String valor){
        valorlist.add(valor);
    }
    
    public void addDatalist(String valor){
        datalist.add(valor);
    }
    
    public void salvarEntradalist(Component rootPane, String user){
        try{
            FileWriter fw = new FileWriter("Arquivos/entrada_"+user+".txt",true);  
            PrintWriter pw = new PrintWriter(fw);
            DecimalFormat df1 = new DecimalFormat("###,###,###,###,###.00");
            
            for(int i=0;i<getIndex();i++){
                
                pw.println("Tipo:"+getTipolist(i));
                pw.println("Data:"+getDatalist(i));
                pw.println("Nome:"+getNomelist(i));
                pw.println("Valor:"+getValorlist(i));
                pw.println("-");
            }
            pw.close();
        }
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
    }
    
    public void listarEntrada(Component rootPane, String user){
         try{
            FileReader fw = new FileReader("Arquivos/entrada_"+user+".txt");
            BufferedReader br = new BufferedReader(fw);
            String[] valorComSplit = null;
            String str;
            
            while((str = br.readLine()) != null){
                valorComSplit = str.split(":");
                if("Tipo".equals(valorComSplit[0])){
                    this.tipolist.add(valorComSplit[1]);
                }
                if("Data".equals(valorComSplit[0])){
                    this.datalist.add(valorComSplit[1]);
                }
                if("Nome".equals(valorComSplit[0])){
                    this.nomelist.add(valorComSplit[1]);
                }
                if("Valor".equals(valorComSplit[0])){
                    this.valorlist.add(valorComSplit[1]);
                }
                
            }
            br.close();
        }
         
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
    }
   
    
}
