/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.classes;

import java.awt.Component;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.print.Doc;
import javax.print.DocFlavor;
import javax.print.DocPrintJob;
import javax.print.PrintException;
import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import javax.print.SimpleDoc;
import javax.swing.JOptionPane;

/**
 *
 * @author T-Gamer
 */
public class Impressao {
    
    // variavel estatica porque será utilizada por inumeras threads  
    private static PrintService impressora;  

    public Impressao() {  

        detectaImpressoras();  

    }  

    // O metodo verifica se existe impressora conectada e a  
    // define como padrao.  
    public void detectaImpressoras() {

        try {  

            DocFlavor df = DocFlavor.SERVICE_FORMATTED.PRINTABLE;  
            PrintService[] ps = PrintServiceLookup.lookupPrintServices(df, null);  
            for (PrintService p: ps) {

                System.out.println("Impressora encontrada: " + p.getName());  

                if (p.getName().contains("Text") || p.getName().contains("Generic"))  {  

                    System.out.println("Impressora Selecionada: " + p.getName());  
                    impressora = p;  
                    break;  

                }  

            }  

        } catch (Exception e) {  

            e.printStackTrace();  

        }  

    }  

    public synchronized boolean imprime(String user, Component rootPane) {

        // se nao existir impressora, entao avisa usuario  
        // senao imprime texto  
        if (impressora == null) {  

            String msg = "Nennhuma impressora foi encontrada. Instale uma impressora padrão \r\n(Generic Text Only) e reinicie o programa.";  
            JOptionPane.showMessageDialog(rootPane, msg, "ERRO", JOptionPane.ERROR_MESSAGE, null);

        } else {  

            try {

                DocPrintJob dpj = impressora.createPrintJob();

                DocFlavor flavor = DocFlavor.INPUT_STREAM.AUTOSENSE;
                Doc doc = new SimpleDoc("impressao"+user+".txt", flavor, null);
                dpj.print(doc, null);  

                return true;  

            } catch (PrintException e) {  

                e.printStackTrace();  

            }  

        }  

        return false;  

    }  

}

