/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.classes;

import java.awt.Component;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.DateFormatSymbols;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author T-Gamer
 */
public class Data {
    
    public int saldo;
    
    private final List<String> nomelistE = new ArrayList<>();
    private final List<String> valorlistE = new ArrayList<>();
    private final List<String> nomelistS = new ArrayList<>();
    private final List<String> valorlistS = new ArrayList<>();
    private final List<String> relatolist = new ArrayList<>();
    private final List<String> valorrelatolist = new ArrayList<>();
    private final List<String> relatolistS = new ArrayList<>();
    private final List<String> valorrelatolistS = new ArrayList<>();
    
     public String getNomelist(int n){
        return nomelistE.get(n);
    }
     
    public String getNomelistS(int n){
        return nomelistS.get(n);
    }

    public String getValorlist(int n){
        return valorlistE.get(n);
    }
    
    public String getValorlistS(int n){
        return valorlistS.get(n);
    }
    
    public String getRelatolist(int n){
        return relatolist.get(n);
    }
    
    public String getValorRelatolist(int n){
        return valorrelatolist.get(n);
    }
    
     public String getRelatolistS(int n){
        return relatolistS.get(n);
    }
    
    public String getValorRelatolistS(int n){
        return valorrelatolistS.get(n);
    }
    
    public String setNomelist(int n ,String valor){
        return nomelistE.set(n, valor);
    }
    
    public String setNomelistS(int n ,String valor){
        return nomelistS.set(n, valor);
    }
    
    public String setValorlist(int n ,String valor){
        return valorlistE.set(n, valor);
    }
    
    public String setValorlistS(int n ,String valor){
        return valorlistS.set(n, valor);
    }
    
    public String setRelatolist(int n, String valor){
        return relatolist.set(n, valor);
    }
    
    public String setValorRelatolist(int n, String valor){
        return valorrelatolist.set(n, valor);
    }
    
    public String setRelatolistS(int n, String valor){
        return relatolistS.set(n, valor);
    }
    
    public String setValorRelatolistS(int n, String valor){
        return valorrelatolistS.set(n, valor);
    }
    
    public int getIndexEntrada(){
        return nomelistE.size();
    }
    
    public int getIndexSaida(){
        return nomelistS.size();
    }
    
    public int getIndexRelato(){
        return relatolist.size();
    }
    
    public int getIndexRelatoS(){
        return relatolistS.size();
    }
    
    public void addNomelist(String valor){
        nomelistE.add(valor);
    }
    
     public void addNomelistS(String valor){
        nomelistS.add(valor);
    }
    
    public void addValorlist(String valor){
        valorlistE.add(valor);
    }
    
    public void addValorlistS(String valor){
        valorlistS.add(valor);
    }
    
    public void addRelatolist(String valor){
        relatolist.add(valor);
    }
    
    public void addValorRelatolist(String valor){
        valorrelatolist.add(valor);
    }
    
    public void addRelatolistS(String valor){
        relatolistS.add(valor);
    }
    
    public void addValorRelatolistS(String valor){
        valorrelatolistS.add(valor);
    }
    
    
    
    public void eliminarNomes(){
        int i;
        int a = getIndexEntrada();
        for(i=0;i<a;i++){
            nomelistE.remove(i);
        }
        
        int j;
        int b = getIndexSaida();
        for(j=0;j<b;j++){
            nomelistS.remove(i);
        }
    }
    
    public void eliminarValores(){
        int i;
        int a = getIndexEntrada();
        for(i=0;i<a;i++){
            valorlistE.remove(i);
        }
        
        int j;
        int b = getIndexSaida();
        for(j=0;j<b;j++){
            valorlistS.remove(i);
        }
    }
    
    
    

    public String dataAtualGregorianCalendar(Date data) {
        DateFormat formata = DateFormat.getDateInstance();
        String resultado = formata.format(data);
        return resultado;
    }
    
    
    
    public void dataSemanal(int mes, String anoA, JComboBox cmb_periodo, Component rootPane, String user, JTable tabelaE, JTable tabelaS, javax.swing.JLabel lbl_saldo, JComboBox cmb_mes, JComboBox cmb_ano) throws ParseException, IOException {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        Date dateHj = new Date();
        String d1 = dataAtualGregorianCalendar(dateHj);

        String s = "";
        s = d1;
        
        String separador[];

        separador = s.split("/");

        int day = Integer.parseInt(separador[0]);
        int mesS = mes;
        String anoS = anoA;

        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        Date date = (Date) formatter.parse(s);
        int mesF = mesS;
        
        int ano = Integer.parseInt(anoS);
        Calendar cal = new GregorianCalendar();
        int primeiroDiaMes = mes;
        primeiroDiaMes = (cal.getMinimum(Calendar.DAY_OF_MONTH));
        String [] splitdata;
        String dialouco;
        String dialegal = Integer.toString(primeiroDiaMes);
        splitdata = dialegal.split("/");
        dialouco = splitdata[0];
        primeiroDiaMes = Integer.parseInt(dialouco);
        
        int ultimoDiaDoMes = (cal.getMaximum(Calendar.DAY_OF_MONTH));

        //===========================

        String formato = "dd/MM/yyyy";
        SimpleDateFormat df = new SimpleDateFormat(formato); //Formata a Data para "dd/MM/yyyy"

        String[] DIA_SEMANA_EXTENSO = new DateFormatSymbols(new Locale("pt", "BR")).getWeekdays(); //Isso é o que mostrará os dias da semana

        List listaDosDias = new ArrayList();
        //A variável i dentro do for inicia em 1 pois é certo que todo mes começa no dia 1.Correto?rs
        //Ele irá fazer o for enquanto a variavel ir for menor ou igual ao ultimo dia do mes.
        int iniPrimeiraSemana = 0;
            int finPrimeiraSemana = 0;
            int iniSegundaSemana = 0;
            int finSegundaSemana = 0;
            int iniTerceiraSemana = 0;
            int finTerceiraSemana = 0;
            int iniQuartaSemana = 0;
            int finQuartaSemana = 0;
            int iniQuintaSemana = 0;
            int finQuintaSemana = 0;
            int semanas = 0;
        for (int i = 1; i <= ultimoDiaDoMes; i++) {
            String dia;
            dia = String.valueOf(i) + "/" + String.valueOf(mesF) + "/" + String.valueOf(ano); //Aqui eu fiz uma concatenação para mostrar da seguinte forma "dd/MM/yyyy"
            date = df.parse(dia);
            Calendar c = Calendar.getInstance();
            c.setTime(date);
            String diaDaSemana = DIA_SEMANA_EXTENSO[c.get(Calendar.DAY_OF_WEEK)];

            //SABER QUANTAS SEMANAS TEM O MES
            int Omes = mesF;
            semanas = cal.getActualMaximum(Calendar.WEEK_OF_MONTH); //Aqui mostra quantas semanas tem no determinado mês

            //=====================================
/////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
//OS IF's E ELSE's É PARA IDENTIFICAR QUANDO CAI O PRIMEIRO DIA DO MES PARA FUNCIONAR O CALCULO Q FIZ
            if(semanas == 4){
                if(cmb_periodo.getSelectedItem() == "5º Semana"){
                    JOptionPane.showMessageDialog(rootPane, "Este mês não possui 5 semanas", "ERRO", JOptionPane.ERROR_MESSAGE, null);
                }
            }
            
            
            System.out.println(diaDaSemana);
            if (diaDaSemana == "Segunda-feira") {
                
                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = iniPrimeiraSemana + 5;

                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                iniQuartaSemana = finTerceiraSemana + 1;
                finQuartaSemana = iniQuartaSemana + 6;

                //05-SEMANA -- O IF É PRA SABER SE O MES TEM 5 SEMANA - JÁ Q FEVEREIRO SÓ TEM 4
                    if(semanas == 5){
                    
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;
                    }
                break;

            } else if (diaDaSemana == "Terça-feira") {
               
                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = iniPrimeiraSemana + 4;

                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                iniQuartaSemana = finTerceiraSemana + 1;
                finQuartaSemana = iniQuartaSemana + 6;

                //05-SEMANA
                    if(semanas == 5){
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;
                    }
                break;

            } else if (diaDaSemana == "Quarta-feira") {
                
                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = iniPrimeiraSemana + 3;

                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                iniQuartaSemana = finTerceiraSemana + 1;
                finQuartaSemana = iniQuartaSemana + 6;

                //05-SEMANA
                    if(semanas == 5){
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;
                    }
                break;

            } else if (diaDaSemana == "Quinta-feira") {
                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = iniPrimeiraSemana + 2;

                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                iniQuartaSemana = finTerceiraSemana + 1;
                finQuartaSemana = iniQuartaSemana + 6;

                //05-SEMANA
                    if(semanas == 5){                       
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;
                    }
                break;

            } else if (diaDaSemana == "Sexta-feira") {

                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = primeiroDiaMes + 1;

                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                iniQuartaSemana = finTerceiraSemana + 1;
                finQuartaSemana = iniQuartaSemana + 6;

                //05-SEMANA
                    if(semanas == 5){
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;                
                    }
                break;
                
                } else if (diaDaSemana == "Sábado") {

                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = primeiroDiaMes;


                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = iniQuartaSemana + 6;
                

                //05-SEMANA
                    if(semanas == 5){
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;               
                    }
                break;
                
                } else if (diaDaSemana == "Domingo") {

                //01-SEMANA
                iniPrimeiraSemana = primeiroDiaMes;
                finPrimeiraSemana = primeiroDiaMes + 6;


                //02-SEMANA
                iniSegundaSemana = finPrimeiraSemana + 1;
                finSegundaSemana = iniSegundaSemana + 6;

                //03-SEMANA

                iniTerceiraSemana = finSegundaSemana + 1;
                finTerceiraSemana = iniTerceiraSemana + 6;

                //04-SEMANA
                if(semanas == 4){
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = ultimoDiaDoMes;
                    break;
                }
                    iniQuartaSemana = finTerceiraSemana + 1;
                    finQuartaSemana = iniQuartaSemana + 6;
                

                //05-SEMANA
                    if(semanas == 5){
                iniQuintaSemana = finQuartaSemana + 1;
                finQuintaSemana = ultimoDiaDoMes;                
                    }
                break;
                
               }
            
        }
    
        //pegando os arquivos do período específico
            int soma1 = 0;
            int soma2 = 0;
            int saldo = 0;
            Entrada ent = new Entrada();
            Saidas sai = new Saidas();
            ent.listarEntrada(rootPane, user);
            sai.listarSaida(rootPane, user);
            String periodo;
            periodo = "0"+Integer.toString(mes);
            if(getIndexEntrada() != 0 & getIndexSaida() != 0){
                    eliminarNomes();
                    eliminarValores();
            }
            int limite = ent.getIndex();
            int j;
            String split[];
 
            //inicio do for() de entrada
            for(j=0;j<limite;j++){
                String data = ent.getDatalist(j);
                split = data.split("/");
                int Dia = Integer.parseInt(split[0]);
                int Mes = Integer.parseInt(split[1]);
                int Ano = Integer.parseInt(split[2]);
                int periodoInt = Integer.parseInt(periodo);
                if(cmb_periodo.getSelectedItem() == "Mensal"){
                    if(periodo.equals(split[1])){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
                } else if(cmb_periodo.getSelectedItem() == "1º Semana"){
                    String inicio = "0"+Integer.toString(iniPrimeiraSemana);
                    String fim = Integer.toString(finPrimeiraSemana);
                    if((iniPrimeiraSemana <= Dia) == true & (Dia <= finPrimeiraSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
                
                } else if(cmb_periodo.getSelectedItem() == "2º Semana"){
                    if((iniSegundaSemana <= Dia) == true & (Dia <= finSegundaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
                
                } else if(cmb_periodo.getSelectedItem() == "3º Semana"){
                    if((iniTerceiraSemana <= Dia) == true & (Dia <= finTerceiraSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
                } else if(cmb_periodo.getSelectedItem() == "4º Semana"){
                    if((iniQuartaSemana <= Dia) == true & (Dia <= finQuartaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
            
                } else if(cmb_periodo.getSelectedItem() == "5º Semana" & semanas == 5){
                    if((iniQuintaSemana <= Dia) == true & (Dia <= finQuintaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelist(ent.getNomelist(j));
                        addValorlist(ent.getValorlist(j));
                        soma1 += Integer.parseInt((ent.getValorlist(j)));
                    }
            
                }
            
            }
            //fim do for() de entrada
            //inicio do for() de saida
            int limite1 = sai.getIndex();
            for(j=0;j<limite1;j++){
                String data = sai.getDatalist(j);
                split = data.split("/");
                int Dia = Integer.parseInt(split[0]);
                int Mes = Integer.parseInt(split[1]);
                int Ano = Integer.parseInt(split[2]);
                int periodoInt = Integer.parseInt(periodo);
                if(cmb_periodo.getSelectedItem() == "Mensal"){
                    if(periodo.equals(split[1])){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));

                    }
                } else if(cmb_periodo.getSelectedItem() == "1º Semana"){
                    String inicio = "0"+Integer.toString(iniPrimeiraSemana);
                    String fim = Integer.toString(finPrimeiraSemana);
                    if((iniPrimeiraSemana <= Dia) == true & (Dia <= finPrimeiraSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));
                    }
                
                } else if(cmb_periodo.getSelectedItem() == "2º Semana"){
                    if((iniSegundaSemana <= Dia) == true & (Dia <= finSegundaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));
                    }
                
                } else if(cmb_periodo.getSelectedItem() == "3º Semana"){
                    if((iniTerceiraSemana <= Dia) == true & (Dia <= finTerceiraSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));
                    }
                } else if(cmb_periodo.getSelectedItem() == "4º Semana"){
                    if((iniQuartaSemana <= Dia) == true & (Dia <= finQuartaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));
                    }
            
                } else if(cmb_periodo.getSelectedItem() == "5º Semana" & semanas == 5){
                    if((iniQuintaSemana <= Dia) == true & (Dia <= finQuintaSemana) == true & periodoInt == Mes  & ano == Ano){
                        addNomelistS(sai.getNomelist(j));
                        addValorlistS(sai.getValorlist(j));
                        soma2 += Integer.parseInt((sai.getValorlist(j)));
                    }
            
                }
            
            }
            //fim do for() de saida
            
            //setando o saldo total
            saldo = soma1-soma2;
            DecimalFormat df1 = new DecimalFormat("###,###,###,###,###.00");
            lbl_saldo.setText(df1.format(saldo));
            
            //preenchendo as tabelas
            PreencherRelatoEntrada(tabelaE, rootPane);
            PreencherRelatoSaida(tabelaS, rootPane);
            
            
            String data1 = new SimpleDateFormat("dd/MM/yyyy").format(new Date(System.currentTimeMillis()));
            Date horario = cal.getTime();
            String[] datasplit = data1.split("/");
            System.out.println(getIndexEntrada());
            
            
            //escrevendo as informações no arquivo para impressão de relatório
            salvarRelatorioList();
            int mesAtual = cal.get(Calendar.MONTH);
            int diaAtual = cal.get(Calendar.DAY_OF_MONTH);
             try{
            FileWriter fw = new FileWriter("Arquivos/impressao"+user+".txt");  
            PrintWriter pw = new PrintWriter(fw);
            pw.println("RELATÓRIO de: "+cmb_mes.getSelectedItem()+" de "+cmb_ano.getSelectedItem());
            pw.println("PERÍODO: "+cmb_periodo.getSelectedItem());
            pw.println("GERADO NA DATA: "+data1+" às "+horario);
            pw.println("\n");
            pw.println("/////////////////ENTRADAS/////////////////");
            pw.println("\n");
            for(int i=0;i<getIndexRelato();i++){
                pw.println("Nome: "+getRelatolist(i));
                pw.println("Valor: "+df1.format(Integer.parseInt(getValorRelatolist(i))));  
                pw.println("\n");
                 
            }
            pw.println("\n");
            pw.println("/////////////////SAÍDAS/////////////////");
            pw.println("\n");
            for(int i=0;i<getIndexRelatoS();i++){
                pw.println("Nome: "+getRelatolistS(i));
                pw.println("Valor: "+df1.format(Integer.parseInt(getValorRelatolistS(i))));  
                pw.println("\n"); 
            }
            pw.println("\n");
            pw.println("SALDO TOTAL: "+df1.format(saldo));
            pw.close();
        }
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
            
    }
    
    public void PreencherRelatoEntrada(JTable tabela, Component rootPane){
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        System.out.println(getIndexEntrada());
        for(int i=0;i<getIndexEntrada();i++){
                Object[] dados = {getNomelist(i),getValorlist(i)};
                dtmGerencia.addRow(dados);
        }
    }
    

    public void PreencherRelatoSaida(JTable tabela, Component rootPane){
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        for(int i=0;i<getIndexSaida();i++){
                Object[] dados = {getNomelistS(i),getValorlistS(i)};
                dtmGerencia.addRow(dados);
        }
    }
    
    public void salvarRelatorioList(){
        int i;
        int indic = 0;
        int index = 0;
        for(i=0;i<getIndexEntrada();i++){
            String nome = getNomelist(i);
            int j;
            if(getIndexRelato() != 0){
                for(j=0;j<getIndexRelato();j++){
                    if(nome.equals(getRelatolist(j))){
                        indic = 1;
                        index = j;
                        break;
                }
            }
            }
            
            if(indic == 0){
                addRelatolist(nome);
                addValorRelatolist(getValorlist(i));
            }
            else{
                String valor = getValorlist(i);
                int soma = 0;
                soma = Integer.parseInt(getValorRelatolist(index)) + Integer.parseInt(valor);
                setValorRelatolist(index, Integer.toString(soma));
            }
        }
        
        for(i=0;i<getIndexSaida();i++){
            String nome = getNomelistS(i);
            int z;
            int indic1 = 0;
            int index1 = 0;
            if(getIndexRelatoS() != 0){
                for(z=0;z<getIndexRelatoS();z++){
                    if(nome.equals(getRelatolistS(z))){
                        indic1 = 1;
                        index1 = z;
                        break;
                }
            }
            }
            if(indic1 == 0){
                addRelatolistS(nome);
                addValorRelatolistS(getValorlistS(i));
            }
            else if(indic1 == 1){
                String valor = getValorlistS(i);
                int soma1 = 0;
                soma1 = Integer.parseInt(getValorRelatolistS(index1)) + Integer.parseInt(valor);
                setValorRelatolistS(index1, Integer.toString(soma1));
            }
            
        }
    }
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
