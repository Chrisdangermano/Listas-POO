/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.classes;

import java.awt.Component;
import java.text.DecimalFormat;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author T-Gamer
 */
public class Gerencia_Tabela {
    Cliente cl = new Cliente();
    
    
    Entrada ent = new Entrada();
    public void PreencherTabelaEntrada(JTable tabela, Component rootPane){
        Entrada consulta = new Entrada();
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        consulta.listarEntrada(rootPane, cl.pegarUser(rootPane));
        for(int i=0;i<consulta.getIndex();i++){
                Object[] dados = {consulta.getTipolist(i), consulta.getNomelist(i), consulta.getValorlist(i), consulta.getDatalist(i)};
                dtmGerencia.addRow(dados);
        }
    }
    
    Saidas sai = new Saidas();
    public void PreencherTabelaSaida(JTable tabela, Component rootPane){
        Saidas consulta = new Saidas();
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        consulta.listarSaida(rootPane, cl.pegarUser(rootPane));
        for(int i=0;i<consulta.getIndex();i++){
                Object[] dados = {consulta.getTipolist(i), consulta.getNomelist(i), consulta.getValorlist(i), consulta.getDatalist(i)};
                dtmGerencia.addRow(dados);
        }
    }
   
    public void PreencherRelatoEntrada(JTable tabela, Component rootPane){
        Data consulta = new Data();
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        for(int i=0;i<consulta.getIndexEntrada();i++){
                Object[] dados = {consulta.getRelatolist(i), consulta.getValorRelatolist(i)};
                dtmGerencia.addRow(dados);
        }
    }
    

    public void PreencherRelatoSaida(JTable tabela, Component rootPane){
        Data consulta = new Data();
        DefaultTableModel dtmGerencia = (DefaultTableModel) tabela.getModel();
        dtmGerencia.setNumRows(0);
        for(int i=0;i<consulta.getIndexSaida();i++){
                Object[] dados = {consulta.getRelatolistS(i), consulta.getValorRelatolistS(i)};
                dtmGerencia.addRow(dados);
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
