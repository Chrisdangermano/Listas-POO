/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.fatec.classes;

import java.awt.Component;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author T-Gamer
 */
public class Cliente {
    private String nome;
    private String telefone;
    private String endereco;
    private String email;
    private String usuario;
    private String senha;
    private String pessoa;

    public Cliente() {
    }
    

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getPessoa() {
        return pessoa;
    }

    public void setPessoa(String pessoa) {
        this.pessoa = pessoa;
    }
    
    //LISTA
    private final List<String> nomelist = new ArrayList<>();
    private final List<String> telefonelist = new ArrayList<>();
    private final List<String> enderecolist = new ArrayList<>();
    private final List<String> emaillist = new ArrayList<>();
    private final List<String> usuariolist = new ArrayList<>();
    private final List<String> senhalist = new ArrayList<>();
    private final List<String> pessoalist = new ArrayList<>();
    
    public String getNomelist(int n){
        return nomelist.get(n);
    }
    public String getTelefonelist(int n){
        return telefonelist.get(n);
    }
    public String getEnderecolist(int n){
        return enderecolist.get(n);
    }
    public String getEmaillist(int n){
        return emaillist.get(n);
    }
    public String getUsuariolist(int n){
        return usuariolist.get(n);
    }
    public String getSenhalist(int n){
        return senhalist.get(n);
    }
    public String getPessoalist(int n){
        return pessoalist.get(n);
    }
    
    public String setNomelist(int n ,String valor){
        return nomelist.set(n, valor);
    }
    public String setTelefonelist(int n ,String valor){
        return telefonelist.set(n, valor);
    }
    public String setEnderecolist(int n ,String valor){
        return enderecolist.set(n, valor);
    }
    public String setEmaillist(int n ,String valor){
        return emaillist.set(n, valor);
    }
    public String setUsuariolist(int n ,String valor){
        return usuariolist.set(n, valor);
    }
    public String setSenhalist(int n ,String valor){
        return senhalist.set(n, valor);
    }
    public String setPessoalist(int n ,String valor){
        return pessoalist.set(n, valor);
    }
    
    public int getIndex(){
        return usuariolist.size();
    }
    
    
    public void salvarClientes(Component rootPane){
        try{
            FileWriter fw = new FileWriter("cliente.txt",true);
            PrintWriter pw = new PrintWriter(fw);
            
            pw.println("Usuario:"+this.usuario);
            pw.println("Nome:"+this.nome);
            pw.println("Telefone:"+this.telefone);
            pw.println("Email:"+this.email);
            pw.println("Endereço:"+this.endereco);
            pw.println("Pessoa:"+this.pessoa);
            pw.println("Senha:"+this.senha);
            pw.println("-");
            pw.close();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
    }
    
    public void salvarClienteslist(Component rootPane){
        try{
            FileWriter fwc = new FileWriter("cliente.txt");            
            fwc.close();
            
            FileWriter fw = new FileWriter("cliente.txt",true);  
            PrintWriter pw = new PrintWriter(fw);
            
            for(int i=0;i<getIndex();i++){
                pw.println("Usuario:"+this.usuario);
                pw.println("Nome:"+this.nome);
                pw.println("Telefone:"+this.telefone);
                pw.println("Email:"+this.email);
                pw.println("Endereço:"+this.endereco);
                pw.println("Pessoa:"+this.pessoa);
                pw.println("Senha:"+this.senha);
                pw.println("-");
                pw.close();         
            }
            pw.close();
        }
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
    }
    
    public boolean procuraCliente(Component rootPane,String parametro){
       boolean mecheu=false;
        try{
            FileReader fw = new FileReader("cliente.txt");
            BufferedReader br = new BufferedReader(fw);
            String[] valorComSplit = null;
            String str;
            
            while((str = br.readLine()) != null){
                valorComSplit = str.split(":");
                if("Usuario".equals(valorComSplit[0])){
                    if(parametro.equals(valorComSplit[1].toLowerCase())){
                        mecheu = true;
                    }
                }            
            }
            br.close();
        }         
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
        return mecheu;
    }
    
   
    
    public static boolean verificar(Component rootPane, String usuario, String password){
               boolean verifica = false;
        try{
            FileReader fw = new FileReader("cliente.txt");
            FileReader fw1 = new FileReader("cliente.txt");
            BufferedReader br = new BufferedReader(fw);
            BufferedReader br1 = new BufferedReader(fw1);
            String[] valorComSplit = null;
            String[] valorComSplit2 = null;
            String str;
            int cont = 0;
            int cont1 = 0;
            
            while((str = br.readLine()) != null){
                
                valorComSplit = str.split(":");
                if("Usuario".equals(valorComSplit[0])){
                    if(usuario.equals(valorComSplit[1].toLowerCase())){
                        break;
                    }
                }
                cont++;
            }
            
            
            while((str = br1.readLine()) != null){
                valorComSplit2 = str.split(":");
                if("Senha".equals(valorComSplit2[0])){
                    if(password.equals(valorComSplit2[1].toLowerCase())){
                        break;
                    }
                }
                cont1++;
            }
            if(6 == cont1-cont){
                verifica=true;
            }
            
            br.close();
            br1.close();
        }         
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
        return verifica;
    }
    
    public void contaAtiva(Component rootPane, String a){
        try{
            FileWriter fw1 = new FileWriter("contaAtiva.txt");
            PrintWriter pw1 = new PrintWriter(fw1);
            FileReader fr = new FileReader("cliente.txt");
            BufferedReader br = new BufferedReader(fr);
            String str;
            String[] valorComSplit = null;
            String pes = null;
            
            while((str = br.readLine()) != null){
                valorComSplit = str.split(":");
                if("Pessoa".equals(valorComSplit[0])){
                    if("J".equals(valorComSplit[1])){
                        pes = "Juridica";
                    }
                    else if("F".equals(valorComSplit[1])){
                        pes = "Fisica";
                    }
                }
            }
            
            pw1.println("Usuario:"+a);
            pw1.println("Pessoa:"+pes);
            pw1.close();
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
    }
    
    public String pegarUser(Component rootPane){
        String usuario = null;
        try{
            FileReader fw = new FileReader("contaAtiva.txt");
            BufferedReader br1 = new BufferedReader(fw);
            String str1;
            
            String[] Split = null;
            while((str1 = br1.readLine()) != null){
                Split = str1.split(":");
                if("Usuario".equals(Split[0])){
                    usuario = Split[1];
                }
            }
        } 
        catch(IOException e){
             JOptionPane.showMessageDialog(rootPane,e, "ERRO", JOptionPane.ERROR_MESSAGE, null);
        }
        
        return usuario;
    }
    
    
  }